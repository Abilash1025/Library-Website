<?php
session_start();
include("db.php");
?>
<?php
$connect = mysqli_connect("localhost","root","","lowalibrary");
$query="select * from books";
$result=mysqli_query($connect,$query);

?>
<!DOCTYPE html>
<html>
<head>
<title>Fantasy Books </title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="/Lowa/CSS/Navigation.css" type="text/css">
<link rel="stylesheet" href="/Lowa/CSS/footer.css" type="text/css">
<link rel="stylesheet" href="/Lowa/CSS/reserve.css" type="text/css">
<link rel="stylesheet" href="/Lowa/fontawesome-free-5.3.1-web/css/all.min.css">
<link rel="stylesheet" href="/Lowa/CSS/bootstrap.min.css">
<link rel="stylesheet" href="/Lowa/CSS/ionicons-2.0.1/css/ionicons.min.css">
	<script src="/Lowa/js/jquery.min.js"></script>
<script src="/Lowa/js/bootstrap.min.js"></script>


<style>
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  float: left;
  width: 33.3%;
  margin-bottom: 16px;
  padding: 0 5px;
  margin: auto;
  text-align: center;
  font-family: arial;

}

.title {
  color: black;
  font-size: 18px;
}

.btne {

border: none;
background: #C93C3C;
color: #ffffff !important;
font-weight: 100;
font-family:arial;
padding: 10px;
text-transform: uppercase;
border-radius: 6px;
display: inline-block;
transition: all 0.3s ease 0s;
text-decoration:none;
}

.btne:hover {
color: white !important;
font-weight: 500 !important;
letter-spacing: 1px;
background: maroon;
-webkit-box-shadow: 0px 5px 40px -10px rgba(0,0,0,0.57);
-moz-box-shadow: 0px 5px 40px -10px rgba(0,0,0,0.57);
transition: all 0.3s ease 0s;
}

a {

  text-decoration: none;
  font-size: 15px;
  color: black;
}

button:hover, a:hover {
  opacity: 0.9;
}
.booklist{
position: relative;
text-align: center;
color: maroon;

}

.booktext{
	position: absolute;
	top: 50%;
	left: 50%;
	transform: translate(-50%, -50%);
	font-size:35px;
	}

h3{
font-size:35px;
color:#922B21 ;
text-align:center;
}

h2{
font-size:25px;
color:#FFFCFC  ;
text-align:left;
}

</style>
</head>

<div class="topnav" >
	<a href="#Register" onclick="closeForm(),openForm1()" ><i class="fas fa-user"></i> Register</a>
	<a href="#Login" onclick="closeForm1(),openForm()" ><i class="fa fa-sign-in-alt"></i> Login</a>
	<a href="/lowa/search.php"><i class="fa fa-search"></i> Search</a>
	<a class="active" href="/lowa/Book.php" onclick="closeForm(),closeForm1()"><i class="fas fa-book"></i> Books</a>
    <a  href="/lowa/index.php" onclick="closeForm(),closeForm1()"><i class="fa fa-home"></i> Lowa Library Home</a>
</div>

<div class="form-popup" id="myForm">
<form action="fantasy.php" method="POST" class="form-containerr">

    <label for="username"><b>UserName</b></label>
<input type="text" name="uname" placeholder="Enter Username"/>

    <label for="psw"><b>Password</b></label>
<input type="password" name="pass" placeholder="Enter Password"/>

    <button type="submit" value="submit" name="submit"class="btn">Login</button>
    <button type="button" class="btn cancel" onclick="closeForm()">Close</button>
  </form>
</div>

<?php

if(isset($_POST['submit']))
{
	$username=$_POST['uname'];
	$password=$_POST["pass"];
	$sql="SELECT * FROM user WHERE username='$username' and password='$password'";
	$result=mysqli_query($con,$sql);
	$row=mysqli_fetch_array($result);
	$count=mysqli_num_rows($result);
	if($count==1)
	{
		$_SESSION['id']=$username;
			if($row['usertype']=="Librarian")
			{
				header("location:/Lowa/HomeforLibrarian.php");
			}
			else if($row['usertype']=="Lecturer")
			{
				header("location:/Lowa/HomeforLecturer.php");
			}
			else if($row['usertype']=="Students")
			{
				header("location:/Lowa/HomeforStudents.php");
			}
	}
	else{
		echo'<script type="text/javascript">
		alert ("Incorrect id");
		</script>' ;
	}
	
}

?>	

<script>
function openForm() {
  document.getElementById("myForm").style.display = "block";
}

function closeForm() {
  document.getElementById("myForm").style.display = "none";
}
</script>

<div class="form-popup1" id="myForm1">
<form action="fantasy.php" method="POST" class="form-container1">


    <label for="username"><b>Username</b></label>
    <input type="text" placeholder="Enter Username" name="Usernamee" required>

    <label for="psw"><b>New Password</b></label>
    <input type="password" placeholder="Enter New Password" name="passw" required> 
	
	
	<label for="type"><b>User Type</b></label>
<select name="Type" type="text">
  <option value="Librarian">Librarian</option>
  <option value="Lecturer">Lecturer</option>
  <option value="Students">Students</option>
</select>

	<label for="No"><b>Contact No</b></label>
    <input type="text" placeholder="Enter Contact No" name="No" required>	
	
	<label for="add"><b>Email</b></label>
    <input type="text" placeholder="Enter Email" name="add" required>	
	


    <button type="submitt" value="submitt" name="submitt" class="btn" >Register</button>
    <button type="text" class="btn cancel" onclick="closeForm1()" >Close</button>
  </form>
</div>
<script>
function openForm1() {
  document.getElementById("myForm1").style.display = "block";
}

function closeForm1() {
  document.getElementById("myForm1").style.display = "none";
  }


</script>
<?php
include("db.php");
if(isset($_POST ['submitt'])){
	$conn = new mysqli ('localhost','root','','lowalibrary');


if ($conn->connect_error){
	die("Connection failed: ".$conn->connect_error);
}
$sql="INSERT INTO user (username,password,usertype,contactno,email) VALUES('$_POST[Usernamee]','$_POST[passw]','$_POST[Type]','$_POST[No]','$_POST[add]')";
if($conn->query($sql)=== TRUE){
		echo'<script>
		alert ("User Registered successfully");
		</script>' ;
}
$conn->close();
}
?>


<h3 align="center">Available Fantasy books</h3>
<br>


<?php
if(!isset($_POST['send'])){
?>
<form method="post" action="index.php">
<?php
if(isset($_GET['pageno'])){
	$pageno = $_GET['pageno'];
}
else{
	$pageno =1 ;
}

$no_of_records_per_page = 9;
$offset =($pageno - 1)* $no_of_records_per_page;

$conn= mysqli_connect("localhost","root","","lowalibrary");

if(mysqli_connect_errno()){
	echo "Failed to connect to Mysql: ".mysqli_connect_error();
	die();
}

$tottal_page_sql ="select count(*) From books";
$result = mysqli_query($conn,$tottal_page_sql);
$total_rows =mysqli_fetch_array($result)[0]	;
$total_pages=ceil($total_rows/$no_of_records_per_page);

$sql="select * from books where category='fantasy' LIMIT $offset, $no_of_records_per_page";
$res_data=mysqli_query($conn,$sql);

while($row = mysqli_fetch_array($res_data))
{
	echo '

	

  


<div class="card">
<div class="booklist">
<img class="bg-image img1" src="/Lowa/Pictures/1.jpg" style="width:450px;height:350px; object-fit:cover;">


<div class="bg-text">'.$row["bookName"].'</div>

  <div class=booktext></div></div>
  <h1>'.$row["id"].'</h1>
  <p class="title">'.$row["bookName"].'</p>
  <p>'.$row["Author"].'</p>
  <div style="margin: 24px 0;">
    <a href="#"><i class="fa fa-star"></i></a> 
    <a href="#"><i class="fa fa-star"></i></a> 
    <a href="#"><i class="fa fa-star"></i></a> 
    <a href="#"><i class="fa fa-star"></i></a> 

  </div>

</div>
	';
}}
?>



<div style="text-align:center;display:inline-block;
  position: relative;
  align:center;
  bottom: 5px;
  width: 100%;
  border: 2px;
	background-color:maroon;"
>
<div style="display:inline-block;position:relative;">
<div class="pagination" style="position:relative;margin-top:10%;bottom:0;">

<a href="?pageno=1" ><p class=" btn btn-danger " style=" text-decoration:none;color:white;background-color:maroon"><i class="far fa-arrow-alt-circle-left"> First</i> </p> </a>

<p style="background-color:maroon" class="btn btn-danger" class="<?php if($pageno >= $total_pages){
	echo 'disabled';}?>" >
	<a href="<?php
	if($pageno>= $total_pages){
		echo '#';
	}
	else{
		echo"?pageno=".($pageno+1);
	}?>" style="  text-decoration:none;color:white;"><i class="far fa-arrow-alt-circle-right"> Next</i></a>
</p>

<p style="background-color:maroon"  class="btn btn-danger" class="<?php if($pageno <= 1){
	echo 'disabled';}?>">
<a href="<?php
		if($pageno <= 1){
		echo '#';
		}else{echo"?pageno=".($pageno-1);}?>" style="  text-decoration:none;color:white">
<i class="fas fa-chevron-circle-left"> prev</i></a>

</p>

<p style="background-color:maroon"  class="btn btn-danger">
<a href="?pageno=<?php echo $total_pages;?>" style="  text-decoration:none;color:white" >
<i class="fas fa-chevron-circle-right"> Last</i></a></p>
</div>
</div>
</div>







  <div class="footer-dark">
        <footer>

            <div class="container10" style="text-align: center;">
                <div class="row">
				
                    <div class="col-sm-6 col-md-3 item">
                        <h3 style="color:white">Resources</h3>
                        <ul style=" text-align: left; display: inline-block; ">
                            <li ><a href="#">Copyright</a></li>
                            <li ><a href="#">Open acess</a></li>
                            <li><a href="#">Licensing</a></li>
                            <li><a href="#">Public library innovation</a></li>
                        </ul>
                    </div>
                    <div class="col-sm-6 col-md-3 item">
                        <h3 style="color:white;">About</h3>
                        <ul style=" text-align: left; display: inline-block; ">
                            <li ><a href="#">History</a></li>
                            <li ><a href="#">Awards</a></li>
                            <li ><a href="#">Founders</a></li>
                            <li ><a href="#">Accountability</a></li>
                        </ul>
                    </div>
                    <div class="col-md-6 item text">
                        <h3 style="color:white;">Contact Us</h3>
						<div style="text-align: left; display: inline-block;" >
						   <p>  Mobile No - 0766507473</p>
                           <p>Land Line - 0312233667</p>
                           <p>E-mail	  - postbox12@gmail.com</p>
                           <p >Address   - No.10,Main Road, City</p>
                       </div>
                    </div>
                    <div class="col item social">
					<a href="#"><i class="icon ion-social-facebook"></i></a>
					<a href="#"><i class="icon ion-social-twitter"></i></a>
					<a href="#"><i class="icon ion-social-snapchat"></i></a>
					<a href="#"><i class="icon ion-social-instagram"></i></a>
					</div>
                </div>
                <p class="copyright">Lowa State University © 2019</p>
            </div>
        </footer>
    </div>
</body>


</html>
