<?php
$con=new mysqli('localhost','root','','lowalibrary');
?>