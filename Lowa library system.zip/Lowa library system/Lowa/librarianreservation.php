<?php

session_start();
include("db.php");


$connect = mysqli_connect("localhost","root","","lowalibrary");
$query="select * from reservation";
$result=mysqli_query($connect,$query);
if(isset($_SESSION['id']))
{
	
?>
<!DOCTYPE html>
<html>
<head>
<title>Reserve Book List</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="CSS/Navigation.css" type="text/css">
<link rel="stylesheet" href="CSS/footer.css" type="text/css">
<link rel="stylesheet" href="CSS/reserve.css" type="text/css">
<link rel="stylesheet" href="fontawesome-free-5.3.1-web/css/all.min.css">
<link rel="stylesheet" href="CSS/bootstrap.min.css">
<link rel="stylesheet" href="CSS/ionicons-2.0.1/css/ionicons.min.css">
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>

<style>
h3{
font-size:35px;
color:#922B21 ;
text-align:center;
}

h2{
font-size:25px;
color:#922B21 ;
text-align:Center;
}



.tab {
  float: left;
  border: 1px solid #ccc;
  background-color: #f1f1f1;
  width: 30%;
  height: 1000px;
}

/* Style the buttons inside the tab */
.tab button {
  display: block;
  background-color: inherit;
  color: black;
  padding: 22px 16px;
  width: 100%;
  border: none;
  outline: none;
  text-align: left;
  cursor: pointer;
  transition: 0.3s;
  font-size: 17px;
}

/* Change background color of buttons on hover */
.tab button:hover {
  background-color: #ddd;
}

/* Create an active/current "tab button" class */
.tab button.active {
  background-color: #ccc;
}

/* Style the tab content */
.tabcontent {
  float: left;
  padding: 0px 12px;
  border: 1px solid #ccc;
  width: 70%;
  border-left: none;
  height: 1000px;
}


.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  float: left;
  width: 33.3%;
  margin-bottom: 16px;
  padding: 0 5px;
  margin: auto;
  text-align: center;
  font-family: arial;

}

.title {
  color: black;
  font-size: 18px;
}



a {

  text-decoration: none;
  font-size: 15px;
  color: black;
}

button:hover, a:hover {
  opacity: 0.9;
}
.booklist{
position: relative;
text-align: center;
color: maroon;

}

.booktext{
	position: absolute;
	top: 50%;
	left: 50%;
	transform: translate(-50%, -50%);
	font-size:35px;
	}
.btne {

border: none;
background: #C93C3C;
color: #ffffff !important;
font-weight: 100;
font-family:arial;
padding: 10px;
text-transform: uppercase;
border-radius: 6px;
display: inline-block;
transition: all 0.3s ease 0s;
text-decoration:none;
}

.btne:hover {
color: white !important;
font-weight: 500 !important;
letter-spacing: 1px;
background: maroon;
-webkit-box-shadow: 0px 5px 40px -10px rgba(0,0,0,0.57);
-moz-box-shadow: 0px 5px 40px -10px rgba(0,0,0,0.57);
transition: all 0.3s ease 0s;
}

</style>
<script type ="text/javascript">
function delete_data(id){
	if(confirm('Sure to remove?')){
		window.location.href='deleteforreserve.php?id='+id;
	}
}
</script>
</head>
<body style="background-color:#F4F6F6 ">

		<?php
		
	echo'<div class="topnav">
	
	<a href="index.php" ><i class="fa fa-sign-out-alt"></i> Logout</a>
	<a href="booksediting.php" ><i class="fa fa-book"></i> Books</a>
	<a class="active" href="functions.php" ><i class="fas fa-folder-open"></i> Funtions</a>
	<a  href="HomeforLibrarian.php" onclick="closeForm(),closeForm1()"><i class="fa fa-home"></i> profile '.$_SESSION['id'].'</a>
</div>




';
}
else
{
	$redirectUrl='index.php';
	echo'<script type="application/javascript">
	alert("Login to view this page");
	window.location.href="'.$redirectUrl.'";</script>';
}

?>
<br>


  <div class="container">
   <br>
   <h2 align="center">Reservation List</h2><br />
   <h2 align="center">you can search the reserve books based on name or bookname or username or Reserve Date</h2><br />
   <div class="form-group">
    <div class="input-group">
     <input type="text" name="search_text" id="search_text" placeholder="Search by Book Details" class="form-control" />
    </div>
   </div>
   <br />
   <div id="result"></div>
  </div>

<script>
$(document).ready(function(){

 load_data();

 function load_data(query)
 {
  $.ajax({
   url:"fetchforreservation.php",
   method:"POST",
   data:{query:query},
   success:function(data)
   {
    $('#result').html(data);
   }
  });
 }
 $('#search_text').keyup(function(){
  var search = $(this).val();
  if(search != '')
  {
   load_data(search);
  }
  else
  {
   load_data();
  }
 });
});
</script>


  <div class="footer-dark">
        <footer>

            <div class="container10" style="text-align: center;">
                <div class="row">
				
                    <div class="col-sm-6 col-md-3 item">
                        <h3 style="color:white">Resources</h3>
                        <ul style=" text-align: left; display: inline-block; ">
                            <li ><a href="#">Copyright</a></li>
                            <li ><a href="#">Open acess</a></li>
                            <li><a href="#">Licensing</a></li>
                            <li><a href="#">Public library innovation</a></li>
                        </ul>
                    </div>
                    <div class="col-sm-6 col-md-3 item">
                        <h3 style="color:white;">About</h3>
                        <ul style=" text-align: left; display: inline-block; ">
                            <li ><a href="#">History</a></li>
                            <li ><a href="#">Awards</a></li>
                            <li ><a href="#">Founders</a></li>
                            <li ><a href="#">Accountability</a></li>
                        </ul>
                    </div>
                    <div class="col-md-6 item text">
                        <h3 style="color:white;">Contact Us</h3>
						<div style="text-align: left; display: inline-block;" >
						   <p>  Mobile No - 0766507473</p>
                           <p>Land Line - 0312233667</p>
                           <p>E-mail	  - postbox12@gmail.com</p>
                           <p >Address   - No.10,Main Road, City</p>
                       </div>
                    </div>
                    <div class="col item social">
					<a href="#"><i class="icon ion-social-facebook"></i></a>
					<a href="#"><i class="icon ion-social-twitter"></i></a>
					<a href="#"><i class="icon ion-social-snapchat"></i></a>
					<a href="#"><i class="icon ion-social-instagram"></i></a>
					</div>
                </div>
                <p class="copyright">Lowa State University © 2019</p>
            </div>
        </footer>
    </div>
</body>


</html>
