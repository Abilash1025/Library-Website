<?php
require_once("db.php");

session_start();
if(isset($_SESSION['id']))
{
	?>
<!DOCTYPE html>
<html>
<head>
<title>Functions </title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="CSS/Navigation.css" type="text/css">
<link rel="stylesheet" href="CSS/Home.css" type="text/css">
<link rel="stylesheet" href="fontawesome-free-5.3.1-web/css/all.min.css">
<link rel="stylesheet" href="CSS/bootstrap.min.css">
<link rel="stylesheet" href="CSS/ionicons-2.0.1/css/ionicons.min.css">
<link rel="stylesheet" href="CSS/footer.css" type="text/css">

<style>
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  float: left;
  width: 33.3%;
  margin-bottom: 16px;
  padding: 0 10px;
  margin: auto;
  text-align: center;
  font-family: arial;
background-color:#F0F3F8  ;
}

.title {
  color: black;
  font-size: 18px;
}



a {

  text-decoration: none;
  font-size: 15px;
  color: black;
}

button:hover, a:hover {
  opacity: 0.9;
}
.booklist{
position: relative;
text-align: center;
color: maroon;

}



h3{
font-size:35px;
color:#922B21 ;
text-align:center;
}

h2{
font-size:25px;
color:#FFFCFC  ;
text-align:left;
}
.navigation-bar a {
  padding: 0px;
  margin: 0px;
  text-align: center;
  display:inline-block;
  vertical-align:top;
}


.btne {

border: none;
background: #C93C3C;
color: #ffffff !important;
font-weight: 100;
font-family:arial;
padding: 10px;
text-transform: uppercase;
border-radius: 6px;
display: inline-block;
transition: all 0.3s ease 0s;
text-decoration:none;
}

.btne:hover {
color: white !important;
font-weight: 500 !important;
letter-spacing: 1px;
background: maroon;
-webkit-box-shadow: 0px 5px 40px -10px rgba(0,0,0,0.57);
-moz-box-shadow: 0px 5px 40px -10px rgba(0,0,0,0.57);
transition: all 0.3s ease 0s;
}

</style>
</head>
<body style="background-color:#F4F6F6 ">

		<?php
		
	echo'<div class="topnav">
	
	<a href="index.php" ><i class="fa fa-sign-out-alt"></i> Logout</a>
	<a href="booksediting.php" ><i class="fa fa-book"></i> Books</a>
	<a class="active" href="functions.php" ><i class="fas fa-folder-open"></i> Funtions</a>
	<a  href="HomeforLibrarian.php" onclick="closeForm(),closeForm1()"><i class="fa fa-home"></i> profile '.$_SESSION['id'].'</a>
</div>




';
}
else
{
	$redirectUrl='index.php';
	echo'<script type="application/javascript">
	alert("Login to view this page");
	window.location.href="'.$redirectUrl.'";</script>';
}

?>

<br>
<div class="column">
    <div class="card">
      <img src="Pictures/r.jpg" style="width:100%">
      <div class="containers">
<br>        
		<div class="button_cont"  align="center"><a style="text-decoration:none" class="btne" href="librarianreservation.php">Reservation</a></div>
      
      </div>
    </div>
  </div>
  
  <div class="column">
    <div class="card">
      <img src="Pictures/b.jpg"  style="width:100%">
      <div class="containers">
<br>             
			 <div class="button_cont"  align="center"><a style="text-decoration:none" class="btne" href="librarianborrowing.php">Borrowing</a></div>
      </div>
    </div>
  </div>


  <div class="column">
    <div class="card">
      <img src="Pictures/re.jpg"style="width:100%">
      <div class="containers">
      <br>
	  <div class="button_cont"  align="center"><a style="text-decoration:none" class="btne" href="librarianboreturning.php">Return</a></div>       
      </div>
    
	</div>
  </div>
<br>
<div>

<h2>a</h2>

</div>


  <div class="footer-dark">
        <footer>
         <div class="container10" style="text-align: center;">
                <div class="row">
				
                    <div class="col-sm-6 col-md-3 item">
                        <h3 style="color:white">Resources</h3>
                        <ul style=" text-align: left; display: inline-block; ">
                            <li ><a href="#">Copyright</a></li>
                            <li ><a href="#">Open acess</a></li>
                            <li><a href="#">Licensing</a></li>
                            <li><a href="#">Public library innovation</a></li>
                        </ul>
                    </div>
                    <div class="col-sm-6 col-md-3 item">
                        <h3 style="color:white;">About</h3>
                        <ul style=" text-align: left; display: inline-block; ">
                            <li ><a href="#">History</a></li>
                            <li ><a href="#">Awards</a></li>
                            <li ><a href="#">Founders</a></li>
                            <li ><a href="#">Accountability</a></li>
                        </ul>
                    </div>
                    <div class="col-md-6 item text">
                        <h3 style="color:white;">Contact Us</h3>
						<div style="text-align: left; display: inline-block;" >
						   <p>  Mobile No - 0766507473</p>
                           <p>Land Line - 0312233667</p>
                           <p>E-mail	  - postbox12@gmail.com</p>
                           <p >Address   - No.10,Main Road, City</p>
                       </div>
                    </div>
                    <div class="col item social">
					<a href="#"><i class="icon ion-social-facebook"></i></a>
					<a href="#"><i class="icon ion-social-twitter"></i></a>
					<a href="#"><i class="icon ion-social-snapchat"></i></a>
					<a href="#"><i class="icon ion-social-instagram"></i></a>
					</div>
                </div>
                <p class="copyright">Lowa State University © 2019</p>
            </div>
        </footer>
    </div>
</body>


</html>