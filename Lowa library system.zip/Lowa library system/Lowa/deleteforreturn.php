<?php
require_once("db.php");
$pdo_statement=$pdo_conn->prepare("delete from bookreturn where return_id=" . $_GET['id']);
$pdo_statement->execute();
header('location:librarianboreturning.php');
?>