<?php
require_once("db.php");
$pdo_statement=$pdo_conn->prepare("delete from borrowing where borrow_id=" . $_GET['id']);
$pdo_statement->execute();
header('location:librarianborrowing.php');
?>