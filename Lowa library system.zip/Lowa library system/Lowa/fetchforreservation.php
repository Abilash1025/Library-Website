<?php

$connect = mysqli_connect("localhost", "root", "", "lowalibrary");
$output = '';
if(isset($_POST["query"]))
{
 $search = mysqli_real_escape_string($connect, $_POST["query"]);
 $query = "
  SELECT * FROM reservation 
  WHERE bookName LIKE '%".$search."%'
  OR username LIKE '%".$search."%' 
  OR date LIKE '%".$search."%' 

 ";
}
else
{
 $query = "
  SELECT * FROM reservation ORDER BY date DESC
 ";
}
$result = mysqli_query($connect, $query);
if(mysqli_num_rows($result) > 0)
{
 $output .= '
  <div class="table-responsive">
   <table class="table table bordered">
    <tr>
     <th>Book id</th>
     <th>Book Name</th>
     <th>Author</th>
     <th>Category</th>
     <th>Date</th>
     <th>Username</th>
     <th>Contact Number</th>
     <th>Email</th>
    </tr>
 ';
 while($row = mysqli_fetch_array($result))
 {
  $output .= '
    <tr>
    
    <td>'.$row["bookid"].'</td>
    <td>'.$row["bookname"].'</td>
    <td>'.$row["author"].'</td>
    <td>'.$row["category"].'</td>
    <td>'.$row["date"].'</td>
    <td>'.$row["username"].'</td>
    <td>'.$row["contactnum"].'</td>
    <td>'.$row["email"].'</td>
    <td><a class="ajax-action-links" href="borrowing.php?id1='.$row['reserve_id'].'"<p><button class="btne" type="submit" onclick="openSearch()">Borrow</button></p>
</a></td>
<td><a class="ajax-action-links" href="javascript:delete_data('.$row['reserve_id'].')"<p><button class="btne" type="submit" onclick="openSearch()">Delete</button></p>
</a></td>
   </tr>
  ';
 }
 echo $output;
}
else
{
 echo 'Data Not Found';
}

?>