<?php
//fetch.php
$connect = mysqli_connect("localhost", "root", "", "lowalibrary");
$output = '';
if(isset($_POST["query"]))
{
 $search = mysqli_real_escape_string($connect, $_POST["query"]);
 $query = "
  SELECT * FROM books 
  WHERE bookName LIKE '%".$search."%'
  OR Author LIKE '%".$search."%' 
  OR category LIKE '%".$search."%'  
  OR id LIKE '%".$search."%'
 ";
}
else
{
 $query = "
  SELECT * FROM books ORDER BY id
 ";
}
$result = mysqli_query($connect, $query);
if(mysqli_num_rows($result) > 0)
{
 $output .= '
  <div class="table-responsive">
   <table class="table table bordered">
    <tr>
     <th>Book id</th>
     <th>Book Name</th>
     <th>Author</th>
     <th>Category</th>
     <th>Quantity</th>
    </tr>
 ';
 while($row = mysqli_fetch_array($result))
 {
  $output .= '
   <tr>
    <td>'.$row["id"].'</td>
    <td>'.$row["bookName"].'</td>
    <td>'.$row["Author"].'</td>
    <td>'.$row["category"].'</td>
    <td>'.$row["quantity"].'</td>
    <td><a class="ajax-action-links" href="reserve.php?id='.$row['id'].'"<p><button class="btne" type="submit" onclick="openSearch()">Reserve</button></p>
</a></td>
   </tr>
  ';
 }
 echo $output;
}
else
{
 echo 'Data Not Found';
}

?>