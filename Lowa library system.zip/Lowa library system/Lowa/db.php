<?php
$con=new mysqli('localhost','root','','lowalibrary');
$database_username = 'root';
	$database_password = '';
	$pdo_conn = new PDO('mysql:host=localhost:3306;dbname=lowalibrary',$database_username,$database_password);

?>