<?php
require_once("db.php");
$pdo_statement=$pdo_conn->prepare("delete from reservation where reserve_id=" . $_GET['id']);
$pdo_statement->execute();
header('location:librarianreservation.php');
?>