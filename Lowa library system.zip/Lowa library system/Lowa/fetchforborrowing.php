<?php

$connect = mysqli_connect("localhost", "root", "", "lowalibrary");
$output = '';
if(isset($_POST["query"]))
{
 $search = mysqli_real_escape_string($connect, $_POST["query"]);
 $query = "
  SELECT * FROM borrowing 
  WHERE bookName LIKE '%".$search."%'
  OR username LIKE '%".$search."%' 
  OR Borrowing_Date LIKE '%".$search."%'  


 ";
}
else
{
 $query = "
  SELECT * FROM borrowing ORDER BY Borrowing_Date desc
 ";
}
$result = mysqli_query($connect, $query);
if(mysqli_num_rows($result) > 0)
{
 $output .= '
  <div class="table-responsive">
   <table class="table table bordered">
    <tr>
     <th>Book id</th>
     <th>Book Name</th>
     <th>Author</th>
     <th>Category</th>
     <th>Date</th>
     <th>Username</th>
     <th>Contact Number</th>
     <th>Email</th>
     <th>Borrowed Date</th>
     <th>Return Date</th>
    </tr>
 ';
 while($row = mysqli_fetch_array($result))
 {
  $output .= '
    <tr>
    <td>'.$row["bookid"].'</td>
    <td>'.$row["bookname"].'</td>
    <td>'.$row["author"].'</td>
    <td>'.$row["category"].'</td>
    <td>'.$row["date"].'</td>
    <td>'.$row["username"].'</td>
    <td>'.$row["contactnum"].'</td>
    <td>'.$row["email"].'</td>
    <td>'.$row["Borrowing_Date"].'</td>
    <td>'.$row["Return_Date"].'</td>
    <td><a class="ajax-action-links" href="return.php?id='.$row['borrow_id'].'"<p><button class="btne" type="submit" onclick="openSearch()">Return</button></p>
</a></td>
<td><a class="ajax-action-links" href="javascript:delete_data('.$row['borrow_id'].')"<p><button class="btne" type="submit" onclick="openSearch()">Delete</button></p>
</a></td>
   </tr>
  ';
 }
 echo $output;
}
else
{
 echo 'Data Not Found';
}

?>