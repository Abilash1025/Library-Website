<?php
require_once("db.php");
session_start();
if(isset($_SESSION['id']))
{
	?>
<!DOCTYPE html>
<html>
<head>
<title>Library System </title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="CSS/Navigation.css" type="text/css">
<link rel="stylesheet" href="CSS/Home.css" type="text/css">
<link rel="stylesheet" href="fontawesome-free-5.3.1-web/css/all.min.css">
<link rel="stylesheet" href="CSS/bootstrap.min.css">
<link rel="stylesheet" href="CSS/ionicons-2.0.1/css/ionicons.min.css">
<link rel="stylesheet" href="CSS/footer.css" type="text/css">

<style>
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  float: center;
  width: 40%;
  margin-bottom: 16px;
  padding: 0 5px;
  margin: auto;
  text-align: center;
  font-family: arial;
background-color:#F0F3F8  ;
}

.title {
  color: black;
  font-size: 18px;
}



a {

  text-decoration: none;
  font-size: 15px;
  color: black;
}

button:hover, a:hover {
  opacity: 0.9;
}
.booklist{
position: relative;
text-align: center;
color: maroon;

}

.booktext{
	position: absolute;
	top: 50%;
	left: 50%;
	transform: translate(-50%, -50%);
	font-size:35px;
	}


h3{
font-size:35px;
color:#922B21 ;
text-align:center;
}

h2{
font-size:25px;
color:#FFFCFC  ;
text-align:left;
}
.navigation-bar a {
  padding: 0px;
  margin: 0px;
  text-align: center;
  display:inline-block;
  vertical-align:top;
}


.btne {

border: none;
background: #C93C3C;
color: #ffffff !important;
font-weight: 100;
font-family:arial;
padding: 10px;
text-transform: uppercase;
border-radius: 6px;
display: inline-block;
transition: all 0.3s ease 0s;
text-decoration:none;
}

.btne:hover {
color: white !important;
font-weight: 500 !important;
letter-spacing: 1px;
background: maroon;
-webkit-box-shadow: 0px 5px 40px -10px rgba(0,0,0,0.57);
-moz-box-shadow: 0px 5px 40px -10px rgba(0,0,0,0.57);
transition: all 0.3s ease 0s;
}

</style>
</head>

<body style="background-color:#F4F6F6 ">

		<?php
		
	echo'<div class="topnav">
	
	<a href="index.php" ><i class="fa fa-sign-out-alt"></i> Logout</a>
	<a href="booksediting.php" ><i class="fa fa-book"></i> Books</a>
	<a href="functions.php" ><i class="fas fa-folder-open"></i> Funtions</a>
	<a class="active" href="HomeforLibrarian.php" onclick="closeForm(),closeForm1()"><i class="fa fa-home"></i> profile '.$_SESSION['id'].'</a>
</div>




';
}
else
{
	$redirectUrl='index.php';
	echo'<script type="application/javascript">
	alert("Login to view this page");
	window.location.href="'.$redirectUrl.'";</script>';
}




?>



<div class="bg-image img1"></div>


<div class="bg-text">Lowa State University Library <br>	 Librarian Login</div>
</div>
</div>
<br>
<?php
if(!isset($_POST['send'])){
?>

<?php
if(isset($_GET['pageno'])){
	$pageno = $_GET['pageno'];
}
else{
	$pageno =1 ;
}

$no_of_records_per_page = 9;
$offset =($pageno - 1)* $no_of_records_per_page;


if(mysqli_connect_errno()){
	echo "Failed to connect to Mysql: ".mysqli_connect_error();
	die();
}




	$pdo_statement = $pdo_conn->prepare("select * from user where username='" . $_SESSION['id'] . "'LIMIT $offset, $no_of_records_per_page");
	$pdo_statement->execute();
	$result = $pdo_statement->fetchAll();
		if(!empty($result)) { 
		foreach($result as $row) {
	echo '

	

  



<div class="card">
<div class="booklist">
<img src="pictures/Lowalogo.JPG" style="width:450px;height:350px; object-fit:cover;">

  <div class=booktext></div></div>
  <h1 style="color:Darkred">'.$row["usertype"].'</h1>
  <p style="text-align:left;font-weight:bold;color:maroon" class="title">1. Username - '.$row["username"].'</p>
  <p style="text-align:left;font-weight:bold;color:maroon" class="title">2. Password - '.$row["password"].'</p>
  <p style="text-align:left;font-weight:bold;color:maroon" class="title">3. Contact No - '.$row["contactno"].'</p>
  <p style="text-align:left;font-weight:bold;color:maroon" class="title">4. Email id - '.$row["email"].'</p>


 	<a class="ajax-action-links" href="profileeditlibrarian.php?id='.$row['username'].'"<p><button class="btne" type="submit" >Edit profile</button></p>
</a>
</div>




	';
}}}
?>

<div style="background-color:#C5">
<h3 >About Us</h3>
</div>
<h2 style="background-color:#8F0E00 ">Vision</h2>
<p style="font-weight:bold">"Being the national knowledge centre, providing access to library and information services for all."</p>

<h2 style="background-color:#8F0E00 ">Mission</h2>
<p style="font-weight:bold;text-align:center;line-height:30px">"Creating a knowledge society through the preservation of intellectual heritage of the nation.

Development of Lowa State library and information system.

Encouraging the utilization of information and communication technology for an effective library service.

Providing bibliographical services and assisting for book publication."

<h2 style="background-color:#8D2222 ">Founders</h2>
</p>

<div class="container" STYLE="  font-family:sans-serif;">
  <img src="Pictures/01.jpg" alt="Avatar" style="width:100px">
  <p style="font-weight: bold"><span>Robert Downey Jr</span>- CEO at Lowa State University.</p>
  <p>If you only read the books that everyone else is reading, you can only think what everyone else is thinking.</p>
</div>

<div class="container"  STYLE="  font-family:sans-serif;" >
  <img src="Pictures/11.jpg" alt="Avatar" style="width:100px">
  <p style="font-weight: bold"><span>Chris Evans</span>- CEO at Lowa State University Library.</p>
  <p>If you only read the books that everyone else is reading, you can only think what everyone else is thinking.</p>
</div>








</div>
  <div class="footer-dark">
        <footer>

            <div class="container10" style="text-align: center;">
                <div class="row">
				
                    <div class="col-sm-6 col-md-3 item">
                        <h3 style="color:white">Resources</h3>
                        <ul style=" text-align: left; display: inline-block; ">
                            <li ><a href="#">Copyright</a></li>
                            <li ><a href="#">Open acess</a></li>
                            <li><a href="#">Licensing</a></li>
                            <li><a href="#">Public library innovation</a></li>
                        </ul>
                    </div>
                    <div class="col-sm-6 col-md-3 item">
                        <h3 style="color:white;">About</h3>
                        <ul style=" text-align: left; display: inline-block; ">
                            <li ><a href="#">History</a></li>
                            <li ><a href="#">Awards</a></li>
                            <li ><a href="#">Founders</a></li>
                            <li ><a href="#">Accountability</a></li>
                        </ul>
                    </div>
                    <div class="col-md-6 item text">
                        <h3 style="color:white;">Contact Us</h3>
						<div style="text-align: left; display: inline-block;" >
						   <p>  Mobile No - 0766507473</p>
                           <p>Land Line - 0312233667</p>
                           <p>E-mail	  - postbox12@gmail.com</p>
                           <p >Address   - No.10,Main Road, City</p>
                       </div>
                    </div>
                    <div class="col item social">
					<a href="#"><i class="icon ion-social-facebook"></i></a>
					<a href="#"><i class="icon ion-social-twitter"></i></a>
					<a href="#"><i class="icon ion-social-snapchat"></i></a>
					<a href="#"><i class="icon ion-social-instagram"></i></a>
					</div>
                </div>
                <p class="copyright">Lowa State University © 2019</p>
            </div>
        </footer>
    </div>
</body>


</html>