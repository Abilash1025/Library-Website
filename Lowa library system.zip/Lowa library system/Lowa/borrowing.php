<?php

session_start();

require_once("db.php");
if(!empty($_POST["save_record"])) {

	$sql=("INSERT INTO borrowing ( bookid,bookname,author,category,date,username,contactnum,email,Borrowing_Date,Return_Date ) VALUES('$_POST[id]','$_POST[bname]','$_POST[author]','$_POST[cat]','$_POST[odate]','$_POST[uname]','$_POST[ccnum]','$_POST[email]','$_POST[todayDate]','$_POST[bday]');DELETE FROM reservation WHERE reserve_id= '" . $_GET['id1'] . "';UPDATE books SET quantity=quantity-1 WHERE id ='$_POST[id]' ");
	$pdo_statement=$pdo_conn->prepare($sql);

	$result = $pdo_statement->execute();
	if($result) {
echo '<script type="text/javascript">'; 
echo 'alert("Books Successfully Borrwed");'; 
echo 'window.location.href = "librarianreservation.php";';
echo '</script>';


	}
}
$pdo_statement = $pdo_conn->prepare("SELECT * FROM reservation where reserve_id= '" . $_GET['id1'] . "' ");
$pdo_statement->execute();
$result = $pdo_statement->fetchAll();
if(isset($_SESSION['id']))
{
?>
<html>
<head>
<link rel="stylesheet" href="CSS/Navigation.css" type="text/css">
<link rel="stylesheet" href="CSS/footer.css" type="text/css">
<link rel="stylesheet" href="CSS/reserve.css" type="text/css">
<link rel="stylesheet" href="fontawesome-free-5.3.1-web/css/all.min.css">
<link rel="stylesheet" href="CSS/bootstrap.min.css">
<link rel="stylesheet" href="CSS/ionicons-2.0.1/css/ionicons.min.css">
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>

<title>Borrow Books</title>
<style>
h3{
font-size:35px;
color:#922B21 ;
text-align:center;
}
h1{
font-size:25px;
color:#922B21 ;
text-align:center;
}

h2{
font-size:25px;
color:maroon  ;
text-align:center;
}
.navigation-bar a {
  padding: 0px;
  margin: 0px;
  text-align: center;
  display:inline-block;
  vertical-align:top;
}

* {
  box-sizing: border-box;
}

.row {
  display: -ms-flexbox; /* IE10 */
  display: flex;
  -ms-flex-wrap: wrap; /* IE10 */
  flex-wrap: wrap;
  margin: 0 -16px;
}

.col-25 {
  -ms-flex: 25%; /* IE10 */
  flex: 25%;
}

.col-50 {
  -ms-flex: 50%; /* IE10 */
  flex: 50%;
}

.col-75 {
  -ms-flex: 75%; /* IE10 */
  flex: 75%;
}

.col-25,
.col-50,
.col-75 {
  padding: 0 16px;
}

.container {
  background-color: #f2f2f2;
  padding: 5px 20px 15px 20px;
  border: 1px solid lightgrey;
  border-radius: 3px;
}

input[type=text] {
  width: 100%;
  margin-bottom: 20px;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 3px;
}

label {
  margin-bottom: 10px;
  display: block;
}

.icon-container {
  margin-bottom: 20px;
  padding: 7px 0;
  font-size: 24px;
}

.btn {
  background-color: #4CAF50;
  color: white;
  padding: 12px;
  margin: 10px 0;
  border: none;
  width: 100%;
  border-radius: 3px;
  cursor: pointer;
  font-size: 17px;
}

.btn:hover {
  background-color: #45a049;
}

a {
  color: #2196F3;
}

hr {
  border: 1px solid lightgrey;
}

span.price {
  float: right;
  color: grey;
}

/* Responsive layout - when the screen is less than 800px wide, make the two columns stack on top of each other instead of next to each other (also change the direction - make the "cart" column go on top) */
@media (max-width: 800px) {
  .row {
    flex-direction: column-reverse;
  }
  .col-25 {
    margin-bottom: 20px;
  }
}




.btne {

border: none;
background: #404040;
color: #ffffff !important;
font-weight: 100;
font-family:arial;
padding: 10px;
text-transform: uppercase;
border-radius: 6px;
display: inline-block;
transition: all 0.3s ease 0s;
text-decoration:none;
}

.btne:hover {
color: white !important;
font-weight: 700 !important;
letter-spacing: 3px;
background: maroon;
-webkit-box-shadow: 0px 5px 40px -10px rgba(0,0,0,0.57);
-moz-box-shadow: 0px 5px 40px -10px rgba(0,0,0,0.57);
transition: all 0.3s ease 0s;
}
.navigation-bar a {
  padding: 0px;
  margin: 0px;
  text-align: center;
  display:inline-block;
  vertical-align:top;
}




</style>
</head>
<body style="background-color:#F1F6F6 ">
<body style="background-color:#F4F6F6 ">

		<?php
		
	echo'<div class="topnav">
	
	<a href="index.php" ><i class="fa fa-sign-out-alt"></i> Logout</a>
	<a href="booksediting.php" ><i class="fa fa-book"></i> Books</a>
	<a class="active" href="functions.php" ><i class="fas fa-folder-open"></i> Funtions</a>
	<a  href="HomeforLibrarian.php" onclick="closeForm(),closeForm1()"><i class="fa fa-home"></i> profile '.$_SESSION['id'].'</a>
</div>




';
}
else
{
	$redirectUrl='index.php';
	echo'<script type="application/javascript">
	alert("Login to view this page");
	window.location.href="'.$redirectUrl.'";</script>';
}

?>



<br>
<br>
<div class="frm-add">
<h3>Book Borrowing</h3>
<form name="frmAdd" action="" method="POST">
<div class="row">
  <div class="col-75">
    <div class="container">
      <form action="borrowing.php">
      
        <div class="row">
          <div class="col-50">
            <h1>Book Details</h1>
            <label for="bid" style="font-weight:bold"><i class="fas fa-id-card"></i> Book Id</label>
  <input type="text" name="id" id="id" class="form-field" value="<?php echo $result[0]['bookid']; ?>" required  />
            <label for="bname" style="font-weight:bold"><i class="fa fa-book"></i> Book Name</label>
  <input type="text" name="bname" id="bname" class="form-field" value="<?php echo $result[0]['bookname']; ?>" required  />
            <label for="bauthor" style="font-weight:bold"><i class="fas fa-book-reader"></i> Author</label>
  <input type="text" name="author" id="author" class="form-field" value="<?php echo $result[0]['author']; ?>" required  />
            <label for="bkcat" style="font-weight:bold"><i class="fas fa-bookmark"></i> Category</label>
  <input type="text" name="cat" id="cat" class="form-field" value="<?php echo $result[0]['category']; ?>" required  />
 <label for="bkcat" style="font-weight:bold"><i class="fas fa-clock"></i> Reserve Date</label>
  <input type="text" name="odate" id="odate" class="form-field" value="<?php echo $result[0]['date']; ?>" required  />



          </div>

          <div class="col-50">
            <h1>User Details</h1>
 
            
            <label for="uname" style="font-weight:bold"><i class="fas fa-user"></i> User Name</label>
   <input type="text" name="uname" id="uname" class="form-field" value="<?php echo $result[0]['username']; ?>" required  />
            <label for="ccnum" style="font-weight:bold"><i class="fas fa-id-card-alt"></i> Contact Number</label>
  <input type="text" name="ccnum" id="ccnum" class="form-field" value="<?php echo $result[0]['contactnum']; ?>" required  />
            <label for="uemail" style="font-weight:bold"><i class="fas fa-envelope-square"></i> Email</label>
   <input type="text" name="email" id="email" class="form-field" value="<?php echo $result[0]['email']; ?>" required  />
      <label for="bkcat" style="font-weight:bold"><i class="fas fa-clock"></i> Borrowing Date</label>
 <input type="text"  name="todayDate" class="form-field" id="todayDate" value="" required  /> 
	<label for="bkcat" style="font-weight:bold"><i class="fas fa-clock"></i> Returning Date</label>
 <input type="date" style="width:100%;" name="bday" class="form-field" value="" required />

	   </div>
    <div class="button_cont"  align="center"><button style="text-decoration:none" value="save_record" name="save_record" class="btne" >Borrow	</button></div>
      
      </div>




  </form>
</div>
 <div class="footer-dark">
        <footer>

            <div class="container10" style="text-align: center;">
                <div class="row">
				
                    <div class="col-sm-6 col-md-3 item">
                        <h3 style="color:white">Resources</h3>
                        <ul style=" text-align: left; display: inline-block; ">
                            <li ><a href="#">Copyright</a></li>
                            <li ><a href="#">Open acess</a></li>
                            <li><a href="#">Licensing</a></li>
                            <li><a href="#">Public library innovation</a></li>
                        </ul>
                    </div>
                    <div class="col-sm-6 col-md-3 item">
                        <h3 style="color:white;">About</h3>
                        <ul style=" text-align: left; display: inline-block; ">
                            <li ><a href="#">History</a></li>
                            <li ><a href="#">Awards</a></li>
                            <li ><a href="#">Founders</a></li>
                            <li ><a href="#">Accountability</a></li>
                        </ul>
                    </div>
                    <div class="col-md-6 item text">
                        <h3 style="color:white;">Contact Us</h3>
						<div style="text-align: left; display: inline-block;" >
						   <p>  Mobile No - 0766507473</p>
                           <p>Land Line - 0312233667</p>
                           <p>E-mail	  - postbox12@gmail.com</p>
                           <p >Address   - No.10,Main Road, City</p>
                       </div>
                    </div>
                    <div class="col item social">
					<a href="#"><i class="icon ion-social-facebook"></i></a>
					<a href="#"><i class="icon ion-social-twitter"></i></a>
					<a href="#"><i class="icon ion-social-snapchat"></i></a>
					<a href="#"><i class="icon ion-social-instagram"></i></a>
					</div>
                </div>
                <p class="copyright">Lowa State University © 2019</p>
            </div>
        </footer>
    </div>
</body>
</html>

<script>
var today=new Date();
var dd= String(today.getDate()).padStart(2,'0');
var mm= String(today.getMonth() + 1).padStart(2,'0');
var yyyy=today.getFullYear();

today=mm+'/'+dd+'/'+yyyy;


console.log("d: "+ dd + " m: " + mm + " y:" + yyyy);
document.getElementById("todayDate").value=today;

document.getElementById("todayDate").readOnly=true;
document.getElementById("bname").readOnly=true;
document.getElementById("author").readOnly=true;
document.getElementById("cat").readOnly=true;
document.getElementById("odate").readOnly=true;
document.getElementById("uname").readOnly=true;
document.getElementById("ccnum").readOnly=true;
document.getElementById("email").readOnly=true;




</script>