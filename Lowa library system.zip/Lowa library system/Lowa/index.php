<?php

session_start();
session_destroy();
session_start();
include("db.php");
?>

<!DOCTYPE html>
<html>
<head>
<title>Library System </title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="CSS/Navigation.css" type="text/css">
<link rel="stylesheet" href="CSS/Home.css" type="text/css">
<link rel="stylesheet" href="fontawesome-free-5.3.1-web/css/all.min.css">
<link rel="stylesheet" href="CSS/bootstrap.min.css">
<link rel="stylesheet" href="CSS/ionicons-2.0.1/css/ionicons.min.css">
<link rel="stylesheet" href="CSS/footer.css" type="text/css">

<style>
h3{
font-size:35px;
color:#922B21 ;
text-align:center;
}

h2{
font-size:25px;
color:#FFFCFC  ;
text-align:left;
}
.navigation-bar a {
  padding: 0px;
  margin: 0px;
  text-align: center;
  display:inline-block;
  vertical-align:top;
}

</style>
</head>
<body style="background-color:#F4F6F6 ">
<!--Navigation Bar-->
<div class="topnav" >

	<a href="#Register" onclick="closeForm(),openForm1()" ><i class="fas fa-user"></i> Register</a>
	<a href="#Login" onclick="closeForm1(),openForm()" ><i class="fa fa-sign-in-alt"></i> Login</a>
	<a href="search.php" onclick="" ><i class="fa fa-search"></i> Search</a>
	<a href="Book.php" onclick="closeForm(),closeForm1()"><i class="fas fa-book"></i> Books</a>
    <a class="active" href="#home" onclick="closeForm(),closeForm1()"><i class="fa fa-home"></i> Lowa Library Home</a>
</div>


<div class="form-popup" id="myForm">
<form action="index.php" method="POST" class="form-containerr">

    <label for="username"><b>UserName</b></label>
<input type="text" name="uname" placeholder="Enter Username"/>

    <label for="psw"><b>Password</b></label>
<input type="password" name="pass" placeholder="Enter Password"/>

    <button type="submit" value="submit" name="submit"class="btn">Login</button>
    <button type="button" class="btn cancel" onclick="closeForm()">Close</button>
  </form>
</div>
<!--Login-->
<?php
if(isset($_POST['submit']))
{
	$username=$_POST['uname'];
	$password=$_POST["pass"];
	$sql="SELECT * FROM user WHERE username='$username' and password='$password'";
	$result=mysqli_query($con,$sql);
	$row=mysqli_fetch_array($result);
	$count=mysqli_num_rows($result);
	if($count==1)
	{
		$_SESSION['id']=$username;
			if($row['usertype']=="Librarian")
			{
				header("location:HomeforLibrarian.php");
			}
			else if($row['usertype']=="Lecturer")
			{
				header("location:Homeforusers.php");
			}
			else if($row['usertype']=="Students")
			{
				header("location:Homeforusers.php");
			}
			
	}
	else{
		echo'<script type="text/javascript">
		alert ("Incorrect id");
		</script>' ;
	}
}
?>	

<script>
function openForm() {
  document.getElementById("myForm").style.display = "block";
}

function closeForm() {
  document.getElementById("myForm").style.display = "none";
}
</script>

<div class="form-popup1" id="myForm1">
<form action="index.php" method="POST" class="form-container1">


    <label for="username"><b>Username</b></label>
    <input type="text" placeholder="Enter Username" name="Usernamee" required>

    <label for="psw"><b>New Password</b></label>
    <input type="password" placeholder="Enter New Password" name="passw" required> 
	
	
	<label for="type"><b>User Type</b></label>
<select name="Type" type="text">
  <option value="Librarian">Librarian</option>
  <option value="Lecturer">Lecturer</option>
  <option value="Students">Students</option>
</select>

	<label for="No"><b>Contact No</b></label>
    <input type="text" placeholder="Enter Contact No" name="No" required>	
	
	<label for="add"><b>Email</b></label>
    <input type="text" placeholder="Enter Email" name="add" required>	
	


    <button type="submitt" value="submitt" name="submitt" class="btn" >Register</button>
    <button type="text" class="btn cancel" onclick="closeForm1()" >Close</button>
  </form>
</div>
<!--Register-->
<script>
function openForm1() {
  document.getElementById("myForm1").style.display = "block";
}

function closeForm1() {
  document.getElementById("myForm1").style.display = "none";
  }


</script>
<?php
include("db.php");
if(isset($_POST ['submitt'])){
	$conn = new mysqli ('localhost','root','','lowalibrary');


if ($conn->connect_error){
	die("Connection failed: ".$conn->connect_error);
}
$sql="INSERT INTO user (username,password,usertype,contactno,email) VALUES('$_POST[Usernamee]','$_POST[passw]','$_POST[Type]','$_POST[No]','$_POST[add]')";
if($conn->query($sql)=== TRUE){
		echo'<script>
		alert ("User Registered successfully");
		</script>' ;
}
$conn->close();
}
?>


<div class="bg-image img1"></div>


<div class="bg-text">Lowa State University Library</div>
</div>
</div>
<div >
<div style="background-color:#C5">
<h3 >About Us</h3>
</div>
<h2 style="background-color:#8F0E00 ">Vision</h2>
<p style="font-weight:bold">"Being the national knowledge centre, providing access to library and information services for all."</p>

<h2 style="background-color:#8F0E00 ">Mission</h2>
<p style="font-weight:bold;text-align:center;line-height:30px">"Creating a knowledge society through the preservation of intellectual heritage of the nation.

Development of Lowa State library and information system.

Encouraging the utilization of information and communication technology for an effective library service.

Providing bibliographical services and assisting for book publication."

<h2 style="background-color:#8D2222 ">Founders</h2>
</p>


<div class="container" STYLE="  font-family:sans-serif;">
  <img src="Pictures/01.jpg" alt="Avatar" style="width:100px">
  <p style="font-weight: bold"><span>Robert Downey Jr</span>- CEO at Lowa State University.</p>
  <p>If you only read the books that everyone else is reading, you can only think what everyone else is thinking.</p>
</div>

<div class="container"  STYLE="  font-family:sans-serif;" >
  <img src="Pictures/11.jpg" alt="Avatar" style="width:100px">
  <p style="font-weight: bold"><span>Chris Evans</span>- CEO at Lowa State University Library.</p>
  <p>If you only read the books that everyone else is reading, you can only think what everyone else is thinking.</p>
</div>

</div>
  <div class="footer-dark">
        <footer>

            <div class="container10" style="text-align: center;">
                <div class="row">
				
                    <div class="col-sm-6 col-md-3 item">
                        <h3 style="color:white">Resources</h3>
                        <ul style=" text-align: left; display: inline-block; ">
                            <li ><a href="#">Copyright</a></li>
                            <li ><a href="#">Open acess</a></li>
                            <li><a href="#">Licensing</a></li>
                            <li><a href="#">Public library innovation</a></li>
                        </ul>
                    </div>
                    <div class="col-sm-6 col-md-3 item">
                        <h3 style="color:white;">About</h3>
                        <ul style=" text-align: left; display: inline-block; ">
                            <li ><a href="#">History</a></li>
                            <li ><a href="#">Awards</a></li>
                            <li ><a href="#">Founders</a></li>
                            <li ><a href="#">Accountability</a></li>
                        </ul>
                    </div>
                    <div class="col-md-6 item text">
                        <h3 style="color:white;">Contact Us</h3>
						<div style="text-align: left; display: inline-block;" >
						   <p>  Mobile No - 0766507473</p>
                           <p>Land Line - 0312233667</p>
                           <p>E-mail	  - postbox12@gmail.com</p>
                           <p >Address   - No.10,Main Road, City</p>
                       </div>
                    </div>
                    <div class="col item social">
					<a href="#"><i class="icon ion-social-facebook"></i></a>
					<a href="#"><i class="icon ion-social-twitter"></i></a>
					<a href="#"><i class="icon ion-social-snapchat"></i></a>
					<a href="#"><i class="icon ion-social-instagram"></i></a>
					</div>
                </div>
                <p class="copyright">Lowa State University © 2019</p>
            </div>
        </footer>
    </div>
</body>


</html>