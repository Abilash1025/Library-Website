-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 17, 2019 at 11:33 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lowalibrary`
--

--
-- Dumping data for table `bookreturn`
--

INSERT INTO `bookreturn` (`return_id`, `bookid`, `bookname`, `author`, `category`, `date`, `username`, `contactnum`, `email`, `Borrowing_Date`, `Return_Date`, `act_ret_date`, `rental`, `fine`, `Total`) VALUES
(1, 4, 'The Andromeda Evolution', 'Michael Crichton', 'Action', '12/08/2019', 'sfdgfhg', 532, 'xc', '12/08/2019', '2019-12-12', '12/08/2019', '100', '0', '100'),
(6, 61, 'Bossypants', 'Terry Pratchett', 'Humor', '12/11/2019', 'raichandran abilash', 1000000, 'abivithi30@gmail.com', '13/12/2019', '2019-12-17', '13/12/2019', '100', '10', '110'),
(7, 1, 'Avengers Endgame:1', 'Russo Brothers', 'Action', '14/12/2019', 'Abilash Stark', 774464844, 'postbox108@gmail.com', '14/12/2019', '2019-12-19', '12/14/2019', '100', '0', '100'),
(8, 1, 'Avengers Endgame A', 'Russo Brothers', 'Action', '12/14/2019', 'Tony', 765048121, 'postbox108@gmail.com', '12/15/2019', '2019-12-17', '12/15/2019', '100', '00', '100');

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `bookName`, `Author`, `category`, `quantity`) VALUES
(1, 'Avengers Endgame A', 'Russo Brothers', 'Action', 6),
(2, 'The Rescue: Ryan Decker, Book 1', 'Steven Konkolyn', 'Action', 10),
(3, 'Hell Divers VI: Allegiance', 'Nicholas Sansbury Smitht', 'Action', 10),
(4, 'The Andromeda Evolution', 'Michael Crichton', 'Action', 10),
(5, 'Final Option', 'Clive Cussler', 'Action', 10),
(6, 'Breakthroughn', 'Michael C. Grumley', 'Action', 10),
(7, 'A Dance with Dragons', 'George R. R. Martin', 'Action', 10),
(8, 'A Clash of Kings', 'George R. R. Martin', 'Action', 10),
(9, 'A Storm of Swords', 'George R. R. Martin', 'Action', 10),
(10, 'One Good Deed', 'Clive Cussler', 'Action', 10),
(11, 'Steve Jobs (Hardcover)', 'Walter Isaacson', 'Biography', 10),
(12, 'The Diary of a Young Girl', 'Anne Frank', 'Biography', 9),
(13, 'Unbroken: A World War II ', 'Laura Hillenbrand', 'Biography', 10),
(14, 'John Adams (Paperback)', 'David McCullough', 'Biography', 10),
(15, 'The Immortal Life ', 'Rebecca Skloot', 'Biography', 10),
(16, 'Alexander Hamilton (Paperback)', 'Ron Chernow', 'Biography', 10),
(17, 'Elon Musk', 'Ashlee Vance', 'Biography', 10),
(18, 'Einstein: His Life and Universe ', ' Walter Isaacson', 'Biography', 10),
(19, 'Into the Wild (Paperback)', 'Jon Krakauer ', 'Biography', 10),
(20, 'Cleopatra: A Life', 'Stacy Schiff', 'Biography', 10),
(22, 'Watchmen', 'Alan Moore and Dave Gibbons', 'comic', 10),
(23, 'Maus: A Survivors Tale', 'Art Spiegelman', 'comic', 12),
(24, 'Daytripper', 'Gabriel Ba and Fabio Moon', 'comic', 10),
(25, 'This One Summer', 'Noelle Stevenson', 'comic', 10),
(26, 'Sweet Tooth', 'Jeff Lemire', 'comic', 10),
(27, 'Through The Woods', ' Emily Carroll', 'comic', 10),
(28, 'Blankets', ' Craig Thompson', 'comic', 10),
(29, 'My Favorite Thing Is Monsters', 'Emil Ferris', 'comic', 10),
(30, 'Jimmy Corrigan', 'Chris Ware', 'comic', 10),
(31, 'The Kite Runner', 'Khaled Hosseini', 'Drama', 10),
(32, 'To Kill a Mockingbird', 'Jack London', 'Drama', 10),
(33, 'A Thousand Splendid Suns', ' Graciliano Ramos', 'Drama', 10),
(34, 'The Green Mile', 'Jack London', 'Drama', 10),
(35, 'The Shining ', 'George Orwell', 'Drama', 10),
(36, 'Coraline', ' José Saramago', 'Drama', 10),
(37, 'The Godfather', 'William Shakespeare', 'Drama', 10),
(38, 'Misery', 'Hamlet Shakespeare', 'Drama', 10),
(39, 'The Appeal', 'Khaled Hosseini', 'Drama', 10),
(40, 'Blindness', 'Khaled Hosseini', 'Drama', 10),
(41, 'Harry potter', ' J.K ROWLING', 'fantasy', 10),
(42, 'THE WAY OF KINGS', 'BRANDON SANDERSON', 'fantasy', 10),
(43, 'HARRY POTTER', 'J.K ROWLING', 'fantasy', 10),
(44, 'A GAME OF THRONES', 'GEORGE R.R. MARTIN', 'fantasy', 10),
(45, 'A WIZARD OF EARTHSEA', 'URSULA LEGUIN', 'fantasy', 11),
(46, 'ASSASSIN’S APPRENTICE', 'ROBIN HOBB', 'fantasy', 10),
(47, 'THE LIES OF LOCKE LAMORA', 'SCOTT LYNCH', 'fantasy', 10),
(48, 'KUSHIEL’S DART', 'JACQUELINE CAREY', 'fantasy', 10),
(49, 'MOON CALLED', 'PATRICIA BRIGGS', 'fantasy', 10),
(50, 'THE LOST HERO', 'RICK RIORDAN', 'fantasy', 10),
(51, 'Ring', 'Koji Suzuki', 'Horror', 10),
(52, 'A Head Full of Ghosts', 'Paul Tremblay', 'Horror', 10),
(53, 'The Damnation Game', 'Clive Barker', 'Horror', 10),
(54, 'Audition', 'Ryu Murakami', 'Horror', 10),
(55, 'The Devil in Silver', 'Victor LaValle', 'Horror', 10),
(56, 'Bird Box', 'Josh Malerman', 'Horror', 10),
(57, 'Burnt Offerings', 'Robert Marasco', 'Horror', 10),
(58, 'John Dies at the End', 'David Wong', 'Horror', 10),
(59, 'Savaging the Dark', 'Christopher Conlon', 'Horror', 10),
(60, 'Rebecca', 'Koji Suzuki', 'Horror', 10),
(61, 'Bossypants', 'Terry Pratchett', 'Humor', 11),
(62, 'Me Talk Pretty One Day', 'Terry Pratchett', 'Humor', 10),
(63, 'Holidays on Ice', 'Joseph Heller', 'Humor', 10),
(64, 'Mort', 'Jim Gaffigan', 'Humor', 10),
(65, 'Modern Romance', 'Maria Semple', 'Humor', 10),
(66, 'The Rosie Project', 'Douglas Adams', 'Humor', 10),
(67, 'Catch-22', 'Jenny Lawson', 'Humor', 10),
(68, 'A Confederacy of Dunces', 'David Sedaris', 'Humor', 10),
(69, 'Equal Rites', 'William Goldman', 'Humor', 10),
(70, ' The Maltese Falcon', 'Terry Pratchett', 'Humor', 10),
(71, 'The Maltese Falcon', 'Dashiell Hammett', 'Mystery', 10),
(72, 'The Girl with the Dragon Tattoo', 'Stieg Larsson', 'Mystery', 10),
(73, 'And Then There Were None', 'Agatha Christie', 'Mystery', 10),
(74, 'The Spy Who Came in From the Cold', 'John Le Carré', 'Mystery', 10),
(75, 'The Postman Always Rings Twice', 'James M. Cain', 'Mystery', 10),
(76, 'The Thirteenth Tale', 'Diane Setterfield', 'Mystery', 10),
(77, 'The Firm', 'John Grisham', 'Mystery', 10),
(78, 'Eye of the Needle', 'Ken Follett', 'Mystery', 10),
(79, 'The Godfather', 'Mario Puzo', 'Mystery', 10),
(80, 'The Big Sleep', 'Raymond Chandler', 'Mystery', 10),
(81, 'The Poet X', 'Elizabeth Acevedo', 'poetry', 10),
(82, 'When the World Didn’t End', 'Caroline Kaufman', 'poetry', 10),
(83, 'When You Ask Me Where I’m Going', 'Jasmin Kaur', 'poetry', 10),
(84, 'Saving Red', 'Sonya Sones', 'poetry', 10),
(85, 'Sold', 'Patricia McCormick', 'poetry', 10),
(86, 'White Rose', 'Raymond Chandler', 'poetry', 10),
(87, 'Light Filters', 'Caroline Kaufman', 'poetry', 10),
(88, 'Ronit & Jamil', 'Pamela L. Laskin', 'poetry', 10),
(89, 'Blood Water Paint', 'Joy McCullough', 'poetry', 10),
(90, 'Impulse', 'Ellen Hopkins', 'poetry', 10),
(91, 'Adbul kalam', 'Tamilarasan', 'Biography', 10);

--
-- Dumping data for table `borrowing`
--

INSERT INTO `borrowing` (`borrow_id`, `bookid`, `bookname`, `author`, `category`, `date`, `username`, `contactnum`, `email`, `Borrowing_Date`, `Return_Date`) VALUES
(7, 62, 'Me Talk Pretty One Day', 'Terry Pratchett', 'Humor', '12/08/2019', 'raichandran abilash', 10, 'vithya.sagar30@gmail.com', '13/12/2019', '2019-12-17'),
(14, 12, 'The Diary of a Young Girl', 'Anne Frank', 'Biography', '13/12/2019', 'raichandran abilash', 10010100, 'vithya.sagar30@gmail.com', '12/14/2019', '2019-12-21');

--
-- Dumping data for table `reservation`
--

INSERT INTO `reservation` (`reserve_id`, `bookid`, `bookname`, `author`, `category`, `date`, `username`, `contactnum`, `email`) VALUES
(1, 2, 'The Rescue: Ryan Decker, Book 1', 'Steven Konkolyn', 'Action', '12/17/2019', 'Vishnu', 2147483647, 'postbox108@gmail.com'),
(2, 4, 'The Andromeda Evolution', 'Michael Crichton', 'Action', '12/17/2019', 'Steve', 2147483647, 'postbox108@gmail.com');

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`username`, `password`, `usertype`, `contactno`, `email`) VALUES
('Tony', '11008', 'Librarian', 76650000, 'postbox@gmail.com'),
('Stark', '2510', 'Lecturer', 766507473, 'postbox1@gmail.com'),
('Peter', '1025', 'Students', 766507473, 'postbox2@gmail.com'),
('Starkster', '10101000', 'Lecturer', 771134545, 'postbox18@gmail.com'),
('Steve', '123456', 'Students', 774567891, 'postbox20@gmail.com'),
('Bruce', '55555', 'Lecturer', 77778885, 'postbox21@gmail.com'),
('banner', '556644', 'Librarian', 2147483647, 'postbox16@gmail.com'),
('Ravi', '147896', 'Librarian', 774464888, 'postbox15@gmail.com'),
('Vishnu', '88888', 'Lecturer', 766507473, 'vishnu30@gmail.com');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
